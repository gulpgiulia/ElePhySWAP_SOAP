function AD = getSONAnalogData(hSMR, ChannelLabel, TimePeriod, fid)
%
%  AD = getSONAnalogData(hSMR, ChannelLabel[, TimePeriod])
%
%  Given an handle hSMR to an opened SMR file, load the analog time series
%  associated to the label ChannelLabel within the time period TimePeriod.
%  If TimePeriod does not exist, the whole time series is loaded.
%
%  Return the time series AD with the fields 
%   dt: sampling interval;
%   value: samples loaded.
%   time: times of the samples
%
% Author: Maurizio Mattia - January 2012

% Search for the analog channel with the specified label...

%*************************************************************************
if ~exist('fid')
    fid=1;
end
%*************************************************************************

k = 1;
for Ch = 1:length(hSMR.ChannelInfo)
   if hSMR.ChannelInfo(Ch).kind == 1
      if strcmpi(ChannelLabel, hSMR.ChannelInfo(Ch).title)
         break
      end
   end
   k = k + 1;
end
if k > length(hSMR.ChannelInfo)
   fprintf(fid,'Channel label not found!\n');
   AD = [];
   return
else
   fprintf(fid,['Loading Channel no. ' num2str(hSMR.ChannelInfo(k).number) ...
         ', label: "' hSMR.ChannelInfo(k).title '"\n']);
end

[data, hCh] = SONGetChannel(hSMR.FileID, hSMR.ChannelInfo(k).number,'scale');
% disp(hCh)

AD.dt = (hCh.stop-hCh.start)/(hCh.npoints-1);

if exist('TimePeriod','var')
   TimePeriod(1) = max([TimePeriod(1) hCh.start]);
   TimePeriod(2) = min([TimePeriod(2) hCh.stop]);
else
   TimePeriod = [hCh.start hCh.stop];
end
ndx = round((TimePeriod(1)-hCh.start)/AD.dt):round((TimePeriod(2)-hCh.start)/AD.dt);
AD.time = ndx * AD.dt + hCh.start;
AD.value = data(ndx+1);
