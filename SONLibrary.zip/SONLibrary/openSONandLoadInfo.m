function hSMR = openSONandLoadInfo(DataFile)
%
%  hSMR = openSONandLoadInfo(DataFile)
%
%     Open data file using SON Library and return a handle (hSMR) with info 
%     about the channels in the recording.
%
% Author: Maurizio Mattia - January 2012


hSMR.FileID = [];
hSMR.ChannelInfo = [];
hSMR.FileHeader = [];

% Load data file...
hSMR.FileID = fopen(DataFile);	
[message, errnum] = ferror(hSMR.FileID);
if (errnum ~= 0)
   disp('Data file did not open!');
   disp(message);
   hSMR = [];
   return
end

% Get file information
hSMR.FileHeader = SONFileHeader(hSMR.FileID);

% Get channel infor
hSMR.ChannelInfo = SONChanList(hSMR.FileID);
