function closeSON(hSMR)
%
%  closeSON(hSMR)
%
%  Close an opened SMR pointed by hSMR...
%
% Author: Maurizio Mattia - January 2012

if fclose(hSMR.FileID) ~= 0
   disp('SON Library: Unable to close Data file!');
   return
end
