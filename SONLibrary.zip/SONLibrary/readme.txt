The SON2 library uses features introduced with version 5 of MATLAB and will not work 
with versions earlier than that.

The SON32 library requires MATLAB version 7.1 or later. 

Unzip the files to the MATLAB work directory. This will create a SON folder containing the SON2 library.
The SON32 library will be installed into a SON\SON32 subfolder.
Add these to th MATLAB path as required.




Malcolm Lidierth
1/10/05

