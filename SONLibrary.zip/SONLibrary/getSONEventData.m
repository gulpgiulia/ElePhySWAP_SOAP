function Events = getSONEventData(hSMR, ChannelLabel, TimePeriod)
%
%  Events = getSONEventData(hSMR, ChannelLabel, TimePeriod)
%
%  Given an handle hSMR to an opened SMR file, load the event time series
%  associated to the label ChannelLabel within the time period TimePeriod.
%  If TimePeriod does not exist, the whole time series is loaded.
%
%  Return the set of event as an array of timestamps 
%   Events: timestamp array
%
% Author: Maurizio Mattia - January 2012

% Search for the digital channel with the specified label...
k = 1;
for Ch = 1:length(hSMR.ChannelInfo)
   if hSMR.ChannelInfo(Ch).kind == 3
      if strcmpi(ChannelLabel, hSMR.ChannelInfo(Ch).title)
         break
      end
   end
   k = k + 1;
end
if k > length(hSMR.ChannelInfo)
   disp('Channel label not found!');
   Events = [];
   return
else
   disp(['Loading Channel no. ' num2str(hSMR.ChannelInfo(k).number) ...
         ', label: "' hSMR.ChannelInfo(k).title '"']);
end

[Events, hCh] = SONGetChannel(hSMR.FileID, hSMR.ChannelInfo(k).number);

if exist('TimePeriod','var')
%    TimePeriod(1) = max([TimePeriod(1) hCh.start]);
%    TimePeriod(2) = min([TimePeriod(2) hCh.stop]);
   Events = Events(Events >= TimePeriod(1) & Events <= TimePeriod(2));
end
