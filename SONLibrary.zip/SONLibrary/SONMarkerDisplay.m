function SONMarkerDisplay(in)
% SONMarkerDisplay is used by sigTOOL and is not part of the stand-alone 
% SON library

return
end