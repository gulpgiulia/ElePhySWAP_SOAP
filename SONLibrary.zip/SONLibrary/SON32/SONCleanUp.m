function SONCleanUp()
% SONCLEANUP File cleanup. Not used in Windows
%
% Author:Malcolm Lidierth
% Matlab SON library:
% Copyright � The Author & King's College London 2005-2006

calllib('son32','SONCleanUp');
return;
