#define SON32 "c:\\Spike5\\son32.dll"
int GetFilterMask();



